
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 622de682cc52a20ec4da320e5221d1bedc2ed752
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Oct 28 17:09:58 2024 +0100
        
            font-patcher: Fix patching woff files
            
            [why]
            After we added the possibility to process font archives (.ttc) we lost
            the ability to process woff and woff2 fonts.
            
            It seems woff(2) files show no font names in fontforge, see
            https://github.com/fontforge/fontforge/issues/1964
            
            [how]
            Open woff(2) files differently.
            
            Fixes: #1647 (further down)
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
