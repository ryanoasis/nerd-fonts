
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit efe57c44fd4819174517d5e6875b34e77fc5c18d
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Apr 27 18:44:48 2023 +0200
        
            Fix: Merge pull request #1179
            
            [why]
            The font-patcher check workflow fails because the font used for testing
            is gone (replaced by differently named one).
            
            [how]
            Correct file names.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
