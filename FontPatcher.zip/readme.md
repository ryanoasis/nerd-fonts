
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 6871fddbf5ac63a472efe7f8882660acc5fe5097
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Mon Apr 22 14:42:12 2024 +0200
        
            Merge pull request #1613 from ryanoasis/bugfix/Caskaydia-long-arrows
            
            font-patcher: Allow to rehint some Cascadia glyphs
