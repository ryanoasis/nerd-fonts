
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 393c66684b5086f579955f7a3ebbf2ab17347c8f
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Jan 15 17:59:11 2024 +0100
        
            font-patcher: Fix debug format string
            
            [why]
            The format string is invalid and results in a runtime error if that
            particular warning is issued (which is only the case for Terminus).
            
            [how]
            A verbatim percent sign must be encoded as '%%'.
            
            [note]
            This has already been fixed before with commit
              f81564fad  font-patcher: Fix typo in logger output
            
            but the change has been lost by rebasing :-(
            
            See also #1350
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
