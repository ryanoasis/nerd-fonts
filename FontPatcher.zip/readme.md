
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 19c416224160f1d8a3378f4e71fb4a720fc1cea7
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Dec 18 15:08:00 2023 +0100
        
            font-patcher: Fix crash if no roman characters
            
            [why]
            When we can not detect the cell width, for example because there are no
            glyphs in the range of extrended-roman that we examine, the width will
            be zero and that will result in a crash later on (on rescaling).
            
            [how]
            Just abort if height or width are zero or negative.
            
            Related: #1460
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
