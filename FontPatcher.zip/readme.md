
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 307e2ad9bfa0c7b913158345ef0d8530246355cc
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Thu Nov 16 18:49:21 2023 +0100
        
            Merge pull request #1419 from ryanoasis/bugfix/powerline-glyph-overlap
            
            Increase Powerline glyph overlap
