
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 327d4b8cabf347732255b2635afe0bf43f673304
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Tue Apr 23 09:45:17 2024 +0200
        
            docs: add gibfahn as a contributor for code (#1618)
            
            * docs: update CONTRIBUTORS.md
            
            * docs: update .all-contributorsrc
            
            ---------
            
            Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
