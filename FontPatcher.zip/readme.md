
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 50a5489424e2713de92d43a573f44c9e02251d44
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed May 3 07:10:09 2023 +0200
        
            font-patcher: Fix logging related warning
            
            [why]
            On some fonts the patcher tries to raise a warning, but it can not.
            
            [how]
            The 'overlap' variable can hold a floating point number or be None (if
            there shall be no overlap processing. Formerly we output that value
            using the {} format, but the logging module does not have that. To
            accomodate to different types use repr() instead.
            
            [note]
            Also improve some other logging related calls.
            
            Reported-by: Jim Myhrberg <contact@jimeh.me>
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
