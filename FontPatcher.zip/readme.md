
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 12b51f51e257a2f63862c6da12b8bb2bb4d9a269
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed Jul 19 11:41:03 2023 +0200
        
            font-patcher: Allow blanks in '--name'
            
            [why]
            If a user specified a name we should probably not camel-casify it.
            
            Fixes (idea mentioned in): #1319
            
            Suggested-by: HUMORCE
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
