
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f81564fadf779ef2e89de87beb1d57d5dff2df15
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Sep 18 11:12:35 2023 +0200
        
            font-patcher: Fix typo in logger output
            
            Fixes: #1350
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
