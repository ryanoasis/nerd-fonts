
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 04e42c1c69b8d74fbbd55c126a2ee6f42d5cbbd9
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Apr 30 23:38:15 2023 +0200
        
            Lekton: Repatch after line spacing fix
            
            [why]
            In the previous commit we changed the way one line metric is choosen
            when they do contradict.
            
            This is the only font affected.
            
            [how]
            Just run gotta-patch-em. The font now uses TYPO (1000) and not WIN (1697)
            anymore.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
