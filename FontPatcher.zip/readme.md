
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a23e33ca87f2a18e6101cd03f180d11d76a0c4e6
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Feb 21 15:08:59 2023 +0100
        
            font-patcher: Allow anonymous fonts
            
            [why]
            When the font has no name the patching fails.
            
            When there is no name we fall back to filename parsing, so it should not
            fail.
            
            [how]
            Check if we have a name. If not do not try to set it.
            
            [note]
            Also change type checks to isinstance() calls.
            
            Fixes: #514
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
