
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit e6426bbc602ff2d47e1109623a1c1b039ab531e8
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Nov 17 21:23:59 2024 +0100
        
            font-patcher: Fix alignment of some glyphs
            
            [why]
            The EE00 and EE03 glyphs are aligned too far to the left.
            
            [how]
            Affected are only right aligned glyphs with (negative) overlap, that
            have an advance width (i.e. are member of a scale group).
            
            Extract a new condition as variable as we need it in several places.
            Use that condition also for the right alignment applicability check.
            
            Related: #1733
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
