
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 6724e6815f347fa041a4f2a224907c9632a46927
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Wed Jul 22 00:20:08 2026 +0200
        
            Merge pull request #2030 from ryanoasis/feature/fa-volume
            
            Add FontAwesome fa-volume
