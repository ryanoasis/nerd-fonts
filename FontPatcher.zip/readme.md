
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 3968deed7563329e675d3afb6f3d299fe601f1c3
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Wed Jan 10 14:16:16 2024 +0100
        
            Merge pull request #1478 from ryanoasis/feature/update-noto-fonts
            
            Update Noto fonts
