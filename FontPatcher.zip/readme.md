
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 01569cad8e2cb5e3211d44e84f1ce94b6ce88349
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Oct 7 12:44:35 2023 +0200
        
            name_parser: Fix weight_string_to_number()
            
            [why]
            Some PS weights have a dash in the weight, like 'Extra-Light' in
            Iosevka. The parser can not parse it because it expects 'ExtraLight'.
            
            [how]
            Filter out all '-' and ' ' from the PS weight string before actually
            parsing the string.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
