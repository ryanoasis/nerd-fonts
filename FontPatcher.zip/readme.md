
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit d311593fa1724ce1e6c639d9b87923332ee2407c
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Fri Mar 29 13:43:54 2024 +0100
        
            Merge pull request #1564 from ryanoasis/feature/prevent-beanpole-icons
            
            font-patcher: Prevent excessively tall icons in mono fonts
