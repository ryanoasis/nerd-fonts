
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 4ab9d898d7c8dcba604d7b9b5e3377d222614948
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Oct 28 16:40:20 2024 +0100
        
            Fixup: Update Font Logos
            
            [why]
            Somehow a wrong Font Logos font is commited.
            
            "River" at F381 missing.
            
            [how]
            Download font from Font Logos Release page and add that.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
