
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 8fc3a7c15a7f8ce763c5b374f8bd8c999e90aeee
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Jun 4 12:23:11 2023 +0200
        
            font-patcher: Add option to suppress renaming
            
            [why]
            Sometimes a user might want to keep the original name.
            
            This is escpecially true as Visual Studio seems to look at the font
            names directly and enables special handling for 'Cascadia Code'.
            Users might want to self-patch without renaming.
            
            [how]
            Add additional value to makegroups option.
            
            That option should probably be renamed into 'naming scheme' or
            something, as it is not really a fitting description of what it does.
            
            Fixes: #1242 (some aspect of it)
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
