
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 4a723e3a43c71462257f0bac281e31206ac643fa
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Apr 12 17:08:24 2024 +0200
        
            doc: Update changelog
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
