
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 438843d57ab4e551d929d5452caa4f32c8ab7228
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon May 22 12:51:15 2023 +0200
        
            FontnameParser: Fix fsSelection for --has-no-italic
            
            [why]
            For fonts that have no Italic but an Oblique - i.e. when Oblique shall
            replace the Italic role in RIBBI font grouping (classic group of 4) -
            that grouping fails.
            
            This affects DejaVu on Putty.
            
            [how]
            For RIBBI grouping only the classic bits are considered. That means that
            for fonts that have Oblique instead of Italic (and not additionally) we
            need to set the ITALIC bit and the OBLIQUE bit. This has been
            overlooked.
            
            Cite from the specs:
            
            > This bit, unlike the ITALIC bit (bit 0), is not related to style-linking
            > in applications that assume a four-member font-family model comprised
            > of regular, italic, bold and bold italic. It may be set or unset
            > independently of the ITALIC bit. In most cases, if OBLIQUE is set, then
            > ITALIC will also be set, though this is not required.
            
            [note]
            Also increase font-patcher version.
            
            Fixes: #1249
            
            Reported-by: Huifeng Shen <liaoya@gmail.com>
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
