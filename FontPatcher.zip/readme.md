
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit cb0c9ed1e7b70a3149dfc55a6c3d5e5941be0eb3
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon May 6 22:08:56 2024 +0200
        
            font-patcher: Fix escaping warnings
            
            [why]
            Some strings have broken format, because the string should contain a
            verbatim backslash.
            
            It seems this is a new warning for Python 3.12
            
            [how]
            Use raw strings or escape the escape character via '\\'
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
