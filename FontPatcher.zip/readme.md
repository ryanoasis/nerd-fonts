
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 156f9bf694fdd3e269bfde2da8e00444110d9993
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed Apr 12 15:19:52 2023 +0200
        
            font-patcher: Add option to manipulate xAvgCharWidth
            
            [why]
            Some old applications seem to depend on obsolete xAvgCharWidth values to
            show two-cell glyphs correctly. Fontforge can only generate OS/2 tables
            version 4, but these applications need 2 or less. In fact they seem to
            not look up the version number, but rely on the value being like it
            always has been ;-)
            
            One example is Windows notepad, that takes the xAvgCharWidth as base for
            the cell size and draws the two-cell chars in a cell twice that size -
            without any regard to glyph width.
            
            [how]
            These issue seems to be encountered rather seldom and only with some
            obscure (grin) applications. There is also no good way to handle this
            automatically. So we add a command line option that allows the user to
            tweak the value after patched-font generation.
            
            The option is called `--xavgcharwidth`:
            * If not specified the behavior of the patcher does not change
            * If just given the xAvgCharWidth is copied over from the source
            * If a number is added that number is used as xAvgCharWidth
            * If the number added is zero we will calculate the old style xAvgCharWidth
            
            Fixes: #522
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
