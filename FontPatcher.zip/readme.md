
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit d45ff3da7525c4a2982256bd3753701780027b4e
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Mar 16 02:04:45 2024 +0100
        
            font-patcher: Increase version
            
            [why]
            Forgot to increase with commit 136a84bc0387406aa.
            
            Now we also have different original icons, lets have a new number.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
