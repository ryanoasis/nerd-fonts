
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit cff81955774f8deab2794e2b983323e46519ceff
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Mar 30 17:37:18 2024 +0100
        
            Iosevka/IosevkaTerm: Prepare patched fonts dir
            
            [why]
            When we drop the subdirectories we probably need to clean
            up the patched-fonts directory first, or the old font will
            not be overwritten.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
