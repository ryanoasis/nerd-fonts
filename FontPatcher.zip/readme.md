
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit d9f7dbe238b6f3dcb83987f6731a3dd64e80b05b
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue May 2 13:23:54 2023 +0200
        
            Prepatched fonts: Revive some ligature removal
            
            [why]
            Some sourcefonts, even that are monospaced, have a `fi` and/or `fl`
            ligature that maps into one cell. That looks very strange.
            
            [how]
            Partially revert commit
              148b0c445  Sunset ligature removal
            
            for the cases that have a one-cell `fi`, `fl`, etc ligature, or a `ldot`
            related ligature - that is active by default. Discretionary ligatures or
            Stylistic Sets are not changed.
            
            Do the removal on all patched fonts for consistency, not just `Nerd Font Mono`.
            
            [note]
            On Noto different subtables are needed for Sans, Serif and Sans-Mono. We
            can not set up different configs for each, so all are tried in all fonts
            and might fail (this is normal).
            Same holds for OpenDyslexic Alta, Regular, Mono, Bold...
            
            Fixes: #1187
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
