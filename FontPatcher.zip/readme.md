
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 43b9ae15d24d6789cbb6b511d0d3641c225b4f47
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon May 8 15:29:37 2023 +0200
        
            Codicons: Preserve smaller icons
            
            [why]
            The codicons have 3 obvious (from the name) pairs of regular and small
            icons. The size difference is slight but visible.
            
            When we maximize all individual icons the differences are mostly lost.
            
            [how]
            Put each pair into one ScaleGroup to keep their individual scaling.
            
            Fixes: #1214
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
