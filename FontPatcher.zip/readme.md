
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 7e0c17c2944e37bfdd4baba7eb6186904cd8fa20
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun May 7 09:52:24 2023 +0200
        
            font-patcher: Drop box-drawing from SymbolsOnly
            
            [why]
            The Box Drawing glyphs need to be carefully scaled. This can not be done
            if the glyphs are pulled in via font-fallback I guess.
            
            As people may have the fontconfig set up in a way to prefer the Symbols
            Only font these glyphs could overrule other box drawing glyphs that
            might fit better.
            
            I'm not really sure about this one, but the glyphs look rather bad
            anyhow, because they end up in the 1:1 ascpect ratio cell of the Symbols
            Only font.
            
            [how]
            Just turn the set off if we patch the Symbols Only font.
            Need to swap around two subroutine calls for that; first detect if we
            are patching the Symbols Only font (through the font metrics) and then
            set the patch sets up.
            
            Fixes: #1210
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
