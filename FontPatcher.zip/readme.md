
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 603a271fa515d8ad23dc3be4ad835b846ccf0422
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Mon Nov 18 12:20:37 2024 +0000
        
            [ci] Rebuild original-source font
