
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit ab37ab5fe4343a8ed66ecb9a80fa540d6285bd74
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Mon Jul 6 10:08:48 2026 +0200
        
            Merge pull request #1992 from ryanoasis/bugfix/2-cell-symbolsonly
            
            font-patcher: Obey two-cell scale rule also with center alignment
            font-patcher: Allow to repair broken fonts with --cell
