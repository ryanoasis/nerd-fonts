
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f9e11168593c01c32223ac4acbbca5fff175b324
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Mar 17 17:14:05 2024 +0100
        
            name-parser: Simplify code
            
            [why]
            The code is rather convoluted and one can not follow what is done.
            
            [how]
            Add function that abstracts some steps away.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
