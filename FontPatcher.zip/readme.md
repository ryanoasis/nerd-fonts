
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 3053972f8691ae3203bc1db10e2e09266012224b
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Sep 23 11:17:59 2023 +0200
        
            font-patcher: Abort if fontforge did not generate patched font
            
            [why]
            Under certain circumjstances Fontforge can not create a font. As the API
            does not give any feedback we trudge along afterwards giving confusing
            messages.
            
            One example is when the patched font contains too many glyphs.
            
            [how]
            Check if the patched font has indeed been generated and is not empty.
            
            Fixes: #1342
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
