
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 4c82de8eb87c248a5d54490f181b745e748b9bdf
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Nov 21 06:56:03 2023 +0100
        
            doc: Remove ancient (out of date) preview fragments
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
