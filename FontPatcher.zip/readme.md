
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit ade9ac7c67c865de68d65bbd41d0b559d7b52e01
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Tue Jul 7 14:09:08 2026 +0200
        
            Merge pull request #2020 from ryanoasis/bugfix/2-cell-rule
            
            Several bugfixes found en passant
