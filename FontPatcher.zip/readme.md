
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit ab18a8135a4702f8cf5fcc58ca6bab9e034ff68c
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Apr 24 15:35:49 2023 +0200
        
            font-patcher: Raise loglevel of VF message
            
            [why]
            When we expect the result to be trash we should say it's critical
            (fatal).
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
