
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f81f17af0d6b95086128dea6bfd8bdcf00868887
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Sat Mar 30 13:28:01 2024 +0100
        
            Merge pull request #1558 from landfillbaby/master
            
            update Intel One Mono to 1.3.0
