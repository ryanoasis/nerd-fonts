
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 798d4ad3db0be56c84d532b88d600c0418e671d7
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Mon Oct 23 11:45:51 2023 +0000
        
            [ci] Rebuild original-source font
