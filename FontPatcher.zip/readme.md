
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 1b7679ebc71f449b6b17f91df2affffa71cb1f35
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Nov 19 22:22:11 2023 +0100
        
            Monaspace: Small forgotten changes
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
