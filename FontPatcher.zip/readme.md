
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 90be3f4264201d6f54f6b0855188a44be9a65720
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Feb 23 17:25:41 2023 +0100
        
            font-patcher: Scale all Material Design Icons individually
            
            [why]
            The Material Design Icons have for sure pairs of glyphs that people
            would like to have scaled identically. Because the sheer number of
            glyphs and because they are already very nicely and uniformly scaled
            within their design space the MDI at the new codepoints where all scaled
            the same with taking the theoretical design space as ScaleGlyph.
            
            But that means all icons get scaled a bit smaller than before, where we
            individually scaled each Material Design Icon to fill the cell.
            This lead to numerous complaints.
            
            [how]
            We take a different approach now, more conventional maybe. Especially in
            the light that the older bigger icons will get dropped; and people love
            them.
            So the uniform scaling is ditched and the individual scaling is used.
            
            Fixes: #1061
            Note: https://github.com/greshake/i3status-rust/pull/1728
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
