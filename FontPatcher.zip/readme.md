
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f84a4a46d2e3352262138472522c9f928ad892e3
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Mar 2 14:18:14 2023 +0100
        
            font-patcher: Add Codicons scale list
            
            [why]
            All glyphs of the codicons set are individually maximised in size.
            That leads to the curious condition that 'circle small' looks bigger
            than 'cicrle' (because the line width is scaled up more -> looks bold).
            
            Also some other 'subsets' look ugly and can not be used together.
            
            [how]
            Add appropriate ScaleGroups.
            
            For the circles we also include one full-size circle as reference. To
            get less than maximal scale for the small circles.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
