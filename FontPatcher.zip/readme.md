
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit ec79b8bc7d17a8632fa9d193d6f4bf70ff4cd0e8
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat May 13 13:04:25 2023 +0200
        
            Update changelog to v3.0.1
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
