
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 1ef53db41f141630dd2e2033be37749a581bfa00
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Mar 19 00:19:28 2024 +0100
        
            Devicons: Fix Materializecss glyph
            
            [why]
            The glyph is extremely complex with very thin open spaces and bridges.
            Obviously a conversion from some colored icon that has not been looked
            at too hard.
            
            [how]
            Remove all the small crevices, smoothen the surface carefully and make
            too thin strokes a bit wider.
            
            We still keep the Devicons goal "very crisp icons" so that no rounding
            of the paths and reduction of points is used.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
