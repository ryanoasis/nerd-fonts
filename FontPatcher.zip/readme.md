
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 59133b8d31ac07189fdcb63dec7bbcb5f23ad94a
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Sun Mar 17 15:31:21 2024 +0100
        
            Merge pull request #1544 from ryanoasis/feature/update-codicons
            
            Update codicons to 0.0.35
