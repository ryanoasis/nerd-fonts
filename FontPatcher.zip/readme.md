
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a3ec4bb22b4beec274f4eedfd800b57f70211f99
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed May 10 11:09:16 2023 +0200
        
            font-patcher: Fix vanishing fi ligature
            
            [why]
            With Ubuntu-Regular the fi and fl ligatures are replaced by some font
            awesome icons.
            
            The problem is that the font uses the non-standard F001 and F002
            codepoints as intermediate referencve to create the actual ligatures
            that are at codepoints FB01 to FB04.
            
            [how]
            All the normal ligature codepoints (FB00-FB06) are added to the glyph
            reference checker and codepoints that are referenced by these are not
            patched.
            
            This means that F001 and F002 stay on the original ligatures and the
            Font Awesome icons are missing, but this can not be fixed automatically
            and would need to 'rewrite' the references inside the font.
            
            Fixes: #1221
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
