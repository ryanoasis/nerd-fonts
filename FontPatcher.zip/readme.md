
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit b95c671ccb501dc7ccfe7c39fadcf3de066a6ecc
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sun Jun 2 08:23:50 2024 +0200
        
            font-patcher: Fix behavior when trying to patch non-font files
            
            [why]
            When the file specified to be patched is not a font file the patcher run
            errors out with an out of index runtime error:
            
            Traceback (most recent call last):
              File "/home/fini/extra/git/nerd-fonts/font-patcher", line 2155, in <module>
                main()
              File "/home/fini/extra/git/nerd-fonts/font-patcher", line 2147, in main
                patcher.generate(sourceFonts)
              File "/home/fini/extra/git/nerd-fonts/font-patcher", line 415, in generate
                sourceFont = sourceFonts[0]
                             ~~~~~~~~~~~^^^
            IndexError: list index out of range
            
            [how]
            Do not assume that the specified file will be a font file but rather
            check if fontforge detects a font in the file and error out if there is
            no font found.
            
            Fixes: #1647
            
            Reported-by: Kristopher James Kent <kris@kjkent.dev>
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
