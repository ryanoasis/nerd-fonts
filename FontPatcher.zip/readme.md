
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit e2f0e9334f1b4d7d9d4cb5b6faca73e25e585e47
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Fri Oct 27 17:28:53 2023 +0000
        
            [ci] Rebuild original-source font
