
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit fecea240834921095cf960b76c320c008ffc83e6
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Mar 28 07:11:37 2024 +0100
        
            Font Awesome: Correct license audit
            
            We specifically use the SVGs to create the intermediate carrier (font
            file) that is used later to patch fonts, to get the icons with a more
            relaxed license. That should be noted in the audit.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
