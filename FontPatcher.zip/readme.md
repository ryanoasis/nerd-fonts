
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 64cf3e9d9309aff62ada7c198960539a3542b797
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Jul 17 09:21:37 2023 +0200
        
            font-patcher: Add option to select postscript name as name source
            
            [why]
            In the post we used these information sources to determine the name and
            weights/styles of the to-be-patched font:
            * The filename
            * The fullname (ID 4)
            * The postscriptname (ID 6)
            
            Usually it is best to use the Fullname of a font to determine its real
            name and styles/weights:
            
            The Postscript name has the advantage to have a hyphen between name and
            styles/weight; but as it can not contain blanks the correct name can not
            be determined by this. To get the styles/weights back we use a list of
            all possible (?!) weights and styles and sort all the string parts.
            
            This works reasonably well and the fullname is usually best.
            
            Not so with Input Mono Condensed. Here are its names:
            ID4: "InputMonoCondensed LightIta"
            IF6: "InputMonoConsensed-LightItalic"
            
            [how]
            Add option to select between fullname and postscriptname as font naming
            source.
            
            For special purposes, also allow a custom (arbitrary) name input.
            If that is given the specified name will be used to name the patched
            font without adding any suffix - the user has full control on the name.
            
            Fixes: #1314
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
