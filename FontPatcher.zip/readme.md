
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 4af1693cb67026bb6f5f7af575f589fb04a786cf
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Mar 30 23:15:26 2024 +0100
        
            Add Recursive Mono
            
            'for Code' variants.
            
            Rename RecMonoSemicausal to RecMonoSemi to avoid too long font names
            after we add 'Nerd Font Mono' )or even (NFM) to it.
            
            Fixes: #845
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
