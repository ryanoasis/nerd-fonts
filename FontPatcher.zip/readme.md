
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit c8bd6d7b6852b8efd8515113a6089c1f6ddde3b4
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed May 3 09:38:52 2023 +0200
        
            font-patcher: Modernize and expand Octicons scale table
            
            [why]
            The scale glyph is not the biggest glyph; the bell-slash is a little bit
            wider than the design cell...
            
            [how]
            Switch to modern ScaleGroups. These determine the virtual combined
            bounding box of all glyphs in the group and scale them 'as one'.
            
            Also add some more groups.
            
            Also correct wrong code of one small stuff.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
