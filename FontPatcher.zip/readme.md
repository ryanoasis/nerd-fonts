
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 930eef239c7467e391a3069f7aca31ff9121fd28
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri May 26 12:10:19 2023 +0200
        
            name-parser: Fix some Blex fonts
            
            [why]
            IBM Plex uses some abbreviations also in the fullname and we do not try
            abbreviations when resolving weights.
            
            [how]
            As this is the only font that has such specials we handle it beforehand
            and do not try all combinations of abbreviated and long keywords.
            
            And then their abbreviations are also not standard - at least not used
            by us or Adobe, etc.
            
            For such a small amount of affected font files it seems in order to
            specifically just fix them instead of a general solution.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
