
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit e5b594faa495b982251fdcd4af87a6d8d4bfd02d
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Apr 4 12:25:01 2024 +0200
        
            CI: Prepare Casks release
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
