
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 8fd192e77ce57bcf4fe85af17e67e1e5f220e8b5
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Thu May 11 15:43:00 2023 +0000
        
            [ci] Rebuild original-source font
