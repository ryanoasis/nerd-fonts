
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit d5d0f2d15429e220776858ef1d586f55e50d367a
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Sun Nov 17 19:57:40 2024 +0100
        
            Merge pull request #1733 from ryanoasis/feature/progress-indicators
            
            font-patcher: Add progress indicators
