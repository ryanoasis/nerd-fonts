
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 707bab33164f5a35dd1d3306d93c4b2eff394f93
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Sun Jul 19 17:40:55 2026 +0200
        
            Merge pull request #1998 from OzelotVanilla/fix/glyph-not-centered-for-mono-option
            
            fix - Some glyph are not visually centered when patching monospaced variation
