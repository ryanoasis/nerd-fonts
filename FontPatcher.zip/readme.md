
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 3dfa80eaa1fd459f7ca6f7920c73f661fa3a8642
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu May 11 21:45:00 2023 +0200
        
            font-patcher: Do not maximize heavy brackets in Mono
            
            [why]
            The added heavy brackets are maximized within the cell size as all
            normal other symbols. But in fact they should not be maximized but
            rather be the size of 'normal brackets'.
            
            Furthermore they are all scaled individually, making the size
            differences less.
            
            With some proportional fonts the brackets look tiny.
            
            [how]
            Introduce new y-padding parameter (because a negative overlap also acts
            in x direction, what we do not want (and it distorts)).
            
            Pad the brackets with 30% (15% top and 15% bottom).
            
            This is used for all fonts (monospaced or not) so that the new glyphs
            fit nicely with the existing ones. For some definitions of 'nicely', but
            that is as good as we can get with automatism. It's not worse than
            font-fallback.
            
            Fixes: #1229
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
