
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 046bdc3ef2dad83dd6960f7b3a8bb999059e62da
        Author: Sebastian Ullrich <sebastian.ullrich@deepsource.de>
        Date:   Tue Apr 11 14:37:03 2023 +0200
        
            Add run comment
