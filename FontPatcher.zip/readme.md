
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit edbce6f1e3c9cff45167750e76e4cf02b7dc6099
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon May 6 22:38:06 2024 +0200
        
            font-patcher: Fix escaping fix
            
            [why]
            With Terminess the regex needs to match literal parens, this has been
            misunderstood with the last commit.
            
            [how]
            Revert the previous commit for Terminess, and use a raw string as
            solution instead (because we usually use raw strings for regexes).
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
