
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 5823665f1f1549186a19a4bfeb0e9bcf3ff2f170
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Apr 14 06:52:17 2023 +0200
        
            font-patcher: Fix patching non-monospaced fonts
            
            [why]
            Any non-monospaced font will not be be patched, the patcher crashes.
            
            [how]
            This must have happened when the box drawing characters rescaling
            feature has been disabled. The default value (False) is not always set.
            
            The box drawing patch has the ability to rescale existing box glyphs.
            That used to be done when all box glyphs are already existing in the
            source font. We do not patch in a new glyph set then, but we rescale the
            existing glyphs to match the possibly new cell size.
            But that feature is disabled and the attribute 'dont-copy' is never
            utilized. It is disabled because some existing box sets are rather ...
            sspecial in their overlap and can not be scaled as we would scale them.
            
            Fixes: #1170
            
            Reported-by: Henrique Monteiro <hrqmonteiro@protonmail.com>
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
