
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit afa6abe0d9e2289c49db94008373323dd6941256
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Feb 17 11:44:13 2023 +0100
        
            archive-font-patcher: Write commit hash instead of tags in readme
            
            [why]
            In the CI we have only a shallow clone of the repo, so access to tags is
            not possible. Instead of resulting in a nice message like '2.3.3-35' we
            get an empty string.
            
            [how]
            As we have no tags we can only write the commit hash and other
            information given in the only existing (i.e. last) commit:
            date, author, title
            
            It's a bit more cumbersome but one can still see from which point in the
            repo the archive has been created.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
