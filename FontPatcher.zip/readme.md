
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 376e39e513830711b5a594fe0073093e5a2b5631
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Mar 10 11:03:18 2023 +0100
        
            CI: Add font with references
            
            [why]
            We had a bug that font-patcher crashes with fonts with references.
            
            [how]
            Just try such a font with all fontforge versions. Just tests if it
            patches, the patch result is not checked.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
