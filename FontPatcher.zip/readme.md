
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 911d6602ed5b7330f6a1909da74a0832a05bec80
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Fri Mar 15 23:15:19 2024 +0000
        
            [ci] Rebuild original-source font
