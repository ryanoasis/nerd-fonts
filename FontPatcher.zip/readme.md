
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit f8a48f93df25c3cf9a468b2cefb9f09e9b5369e3
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Aug 3 12:12:31 2026 +0200
        
            generate-font-image-previews: Fix shellcheck warnings
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
