
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 1bb681473ba4996690e54be698fbb2d83c30af78
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Apr 24 21:11:59 2023 +0200
        
            Drop obsolete MDI, update Octicons
            
            [why]
            The old MDI are kept, just disabled. Maybe we need them or someone else,
            for backward compatibility. Can be dropped sometime in the future.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
