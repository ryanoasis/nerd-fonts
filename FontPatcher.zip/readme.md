
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 50d375afcdd3a214631329c0e49b9e93555a31d4
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Aug 22 12:15:21 2026 +0200
        
            font-patcher: Fix progressbars
            
            [why]
            There were again multiple lines for some glyph sets, where the patching
            happens in chunks. I thought I fixed that (having only one line/bar per
            glyph set) but obviously that is broken.
            
            [how]
            Move the output of the line break - that happens on the start of a new
            set - to the correct position.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
