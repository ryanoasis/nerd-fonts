
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 136a84bc0387406aa134fcda3e40b1013a57f5dd
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Fri Mar 1 12:03:45 2024 +0100
        
            font-patcher: Fix Octicon scaling groups
            
            [why]
            The Octicon scaling group has two errors, one is a typo (the first digit
            of a number is missing), and the second is off by one for some reason.
            
            Reported-by: @aaronbell
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
