
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 2123aea42031882eca629487ea694537141a6acf
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Mon Oct 28 16:11:04 2024 +0100
        
            Update Font Logos to 1.3.0
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
