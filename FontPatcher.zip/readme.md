
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit db900abe1e5efd0eb94d15f1298ef1d48c233831
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Fri Apr 26 13:07:34 2024 +0200
        
            docs: add zaucy as a contributor for code (#1619)
            
            * docs: update CONTRIBUTORS.md
            
            * docs: update .all-contributorsrc
            
            ---------
            
            Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
