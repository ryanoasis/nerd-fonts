
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 2ce56141db21dce79a5f510916807b813fe2fa9f
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed Sep 27 05:35:43 2023 +0200
        
            name-parser: Unify quotes used for strings
            
            [why]
            We use single quotes everywhere else.
            Keep this consistent.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
