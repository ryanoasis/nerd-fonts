
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 8ea2e71b8068174b6f44ead94ef2827c9ab04436
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Tue May 30 22:03:02 2023 +0200
        
            Merge pull request #1261 from ryanoasis/bugfix/codicons-circles
            
            Bugfix Codicon Circles
